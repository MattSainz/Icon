var menuManager = {
	setShortcutFunction: function(func) {
		this.shortcutHandler = func;
	},

	shortcutHandler: function(action) {
		console.log("Menu action performed: " , action);
	}
};

var topBarMenuTemplate = [
	{
		label: 'Postman',
		submenu: [
			{
				label: 'About Postman',
				selector: 'orderFrontStandardAboutPanel:'
			},
			{
				label: 'Check for Updates...',
				click: function() {menuManager.shortcutHandler('checkElectronUpdates')}
			},
			{
				type: 'separator'
			},
			{
				label: 'Preferences',
				accelerator: 'Command+,',
				click: function() {menuManager.shortcutHandler('openSettings')}
			},
			{
				label: 'Services',
				submenu: []
			},
			{
				type: 'separator'
			},
			{
				label: 'Hide Postman',
				accelerator: 'Command+H',
				selector: 'hide:'
			},
			{
				label: 'Hide Others',
				accelerator: 'Command+Shift+H',
				selector: 'hideOtherApplications:'
			},
			{
				label: 'Show All',
				selector: 'unhideAllApplications:'
			},
			{
				type: 'separator'
			},
			{
				label: 'Quit',
				accelerator: 'Command+Q',
				click: function() { menuManager.shortcutHandler("appQuit"); }
			},
		]
	},
	{
		label: 'Collection',
		submenu: [{
			label: 'New Collection',
			click: function() {menuManager.shortcutHandler('newCollection')}
		},
			{
				label: 'Import',
				click: function() {menuManager.shortcutHandler('openImport')}
			},
			{
				label: 'Runner',
				click: function() {menuManager.shortcutHandler('openRunner')}
			}]
	},
	{
		label: 'Edit',
		submenu: [
			{
				label: 'Undo',
				accelerator: 'Command+Z',
				selector: 'undo:'
			},
			{
				label: 'Redo',
				accelerator: 'Shift+Command+Z',
				selector: 'redo:'
			},
			{
				type: 'separator'
			},
			{
				label: 'Cut',
				accelerator: 'Command+X',
				selector: 'cut:'
			},
			{
				label: 'Copy',
				accelerator: 'Command+C',
				selector: 'copy:'
			},
			{
				label: 'Paste',
				accelerator: 'Command+V',
				selector: 'paste:'
			},
			{
				label: 'Select All',
				accelerator: 'Command+A',
				selector: 'selectAll:'
			},
			{
				type: 'separator'
			},
			{
				label: 'New Collection',
				click: function() {menuManager.shortcutHandler('newCollection')}
			},
			{
				label: 'New Request',
				click: function() {menuManager.shortcutHandler('newRequest')}
			},

		]
	},
	{
		label: 'View',
		submenu: [
			{
				label: 'Reload',
				click: function() {
					menuManager.shortcutHandler("reloadWindow");
				}
			},
			{
				label: 'Toggle DevTools',
				accelerator: 'Alt+Command+I',
				click: function() {
					console.log("toggleDevTools shortcut called");
					menuManager.shortcutHandler("toggleDevTools");
				}
			},
			{
				label: 'Fullscreen',
				click: function() { menuManager.shortcutHandler("fullScreen"); }
			},
			{
				label: 'Toggle Sidebar',
				click: function() { menuManager.shortcutHandler('toggleSidebar') }
			},
		]
	},
	{
		label: 'Window',
		submenu: [
			{
				label: 'Minimize',
				accelerator: 'Command+M',
				selector: 'performMiniaturize:'
			},
			{
				type: 'separator'
			},
			{
				label: 'Bring All to Front',
				selector: 'arrangeInFront:'
			},
		]
	},
	{
		label: 'Help',
		submenu: [
			{
				label: 'Github',
				click: function() {menuManager.shortcutHandler("openCustomUrl", "https://github.com/postmanlabs/postman-app-support/")}
			},
			{
				label: 'Twitter',
				click: function() {menuManager.shortcutHandler("openCustomUrl", "https://twitter.com/postmanclient")}
			},
			{
				label: 'Support',
				click: function() {menuManager.shortcutHandler("openCustomUrl", "https://getpostman.com/support")}
			}
		]
	},
];

var dockMenuTemplate = [
	{ label: 'New Collection', click: function() {menuManager.shortcutHandler('newCollection');} },
	{ label: 'New Window ',  click: function() {menuManager.shortcutHandler('newWindow');} }
];

menuManager.topBarMenuTemplate = topBarMenuTemplate;
menuManager.dockMenuTemplate = dockMenuTemplate;

exports.menuManager = menuManager;
