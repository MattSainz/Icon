var BrowserWindow = require('browser-window'),
		Menu = require('menu'),
		menuManager = require('./menuManager').menuManager,
		_ = require('lodash');

exports.windowManager = {
	primaryId: "1",

	mainWindow: null,

	openWindowIds: [],

	requesterPath: null, //set in initialize()

	testRunnerPath: null, //set in initialize()

	thisVersion: null,

	initUrl: null,

	initialize: function(thisVersion) {
		if (process.env.NODE_ENV !== 'development') {
			this.requesterPath = 'file://' + __dirname + '/../html/requester.html';
			this.testRunnerPath = 'file://' + __dirname + '/../html/runner.html';
		}
		else {
			this.requesterPath = 'http://localhost:8777/build/electron/html/requester.html';
			this.testRunnerPath = 'http://localhost:8777/build/electron/html/runner.html';
		}

		this.thisVersion = thisVersion;
	},

	focusFirstWindow: function() {
		var numWindowsLeft = this.openWindowIds.length;
		for(var i=0;i<numWindowsLeft;i++) {
			var bWindow = BrowserWindow.fromId(parseInt(this.openWindowIds[i]));
			if(!bWindow) {
				continue;
			}
			bWindow.show();
			bWindow.restore();
			return;
		}
	},

	sendCustomInternalEvent: function(action) {
		var message = {
			name: "internalEvent",
			data: {
				event: action
			}
		};
		var bWindow = BrowserWindow.getFocusedWindow();
		if(!bWindow) {
			return;
		}
		bWindow.webContents.send('electronWindowMessage', message);
	},

	sendToFirstWindow: function(message) {
		var numWindowsLeft = this.openWindowIds.length;
		for(var i=0;i<numWindowsLeft;i++) {
			var bWindow = BrowserWindow.fromId(parseInt(this.openWindowIds[i]));
			if(!bWindow) {
				continue;
			}
			bWindow.webContents.send('electronWindowMessage', message);
			return;
		}
	},

	sendToAllWindows: function(message) {
		//send event to all other windows
		var numWindowsLeft = 0;
		if(this.openWindowIds && this.openWindowIds.length) {
			numWindowsLeft = this.openWindowIds.length;
		}

		for(var i=0;i<numWindowsLeft;i++) {
			var bWindow = BrowserWindow.fromId(parseInt(this.openWindowIds[i]));
			if(!bWindow) {
				continue;
			}
			bWindow.webContents.send('electronWindowMessage', message);
		}
	},

	sendInternalMessage: function(message) {
		this.sendToAllWindows({
			name: "internalEvent",
			data: message
		});
	},

	setShortcutFunction: function(func) {
		menuManager.setShortcutFunction(func);
	},

	newRequesterWindow: function() {
		var mainWindow = new BrowserWindow({
			width: 1280,
			height: 800,
			"web-preferences": {
				"web-security": false
			}
		});
		var windowId = mainWindow.id + "";
		var oldThis = this;
		this.openWindowIds.push(windowId);

		var template = _.cloneDeep(menuManager.topBarMenuTemplate);
		var menu = Menu.buildFromTemplate(template);
		Menu.setApplicationMenu(menu);

		mainWindow.loadUrl(this.requesterPath);
		if(oldThis.openWindowIds.length == 1) {
			//this is the only window. make it primary
			this.primaryId = mainWindow.id;
		}
		mainWindow.webContents.on('did-finish-load', function() {
			console.log("New window with id: " + windowId + " finished loading. Calling setWindowId. Primary window id: " , oldThis.primaryId);
			console.log("----------------");
			mainWindow.webContents.send('electronWindowMessage', {
				name: "setWindowIds",
				data: {
					thisId: windowId+"",
					primaryId: oldThis.primaryId,
					allIds: oldThis.openWindowIds,
					thisVersion: oldThis.thisVersion
				}
			});
			if(oldThis.initUrl) {
				setTimeout(function() {
					mainWindow.webContents.send('electronWindowMessage', {
						name: "protocolEventOnInit",
						data: oldThis.initUrl
					});
					oldThis.initUrl = null;
				}, 3000);
			}
		});

		// Emitted when the window is closed.
		mainWindow.on('close', function(e) {
			mainWindow = null;
			console.log("Closing window with id: " + windowId);
			oldThis.windowClosed(windowId);
		});

		this.sendInternalMessage({
			event: "pmWindowOpened",
			object: windowId+""
		});
		return windowId;
	},

	newRunnerWindow: function(arg) {
		var mainWindow = new BrowserWindow({
			width: 1280,
			height: 800,
			"web-preferences": {
				"web-security": false
			}
		});
		mainWindow.loadUrl(this.testRunnerPath);
		mainWindow.webContents.on('did-finish-load', function () {
			console.log("Sending test runner attrs");
			console.log(arg);
			mainWindow.webContents.send('setTestRunnerAttrs', arg);
		});
		mainWindow.on('closed', function () {
			mainWindow = null;
		});
	},

	openUrl: function(url) {
		if(this.openWindowIds.length > 0) {
			this.sendToFirstWindow({
				name: "internalEvent",
				data: {
					event: "protocolEvent",
					object: this.initUrl
				}
			});
			this.focusFirstWindow();
			this.initUrl = null;
		}
	},

	windowClosed: function(windowId) {
		//remove windowId from openWindowIds
		var index = this.openWindowIds.indexOf(windowId);
		if(index!==-1) {
			this.openWindowIds.splice(index, 1);
		}

		//send event to all other windows
		this.sendToAllWindows({
			name: "otherWindowClosed",
			data: {
				"id": windowId
			}
		});
	}

};