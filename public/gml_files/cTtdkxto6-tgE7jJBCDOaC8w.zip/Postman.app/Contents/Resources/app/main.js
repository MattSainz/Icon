var app = require("app"),
    autoUpdater = require('auto-updater'),
    BrowserWindow = require('browser-window'),
    _ = require('lodash'),
    Menu = require('menu'),
    shell = require('shell'),
    dialog = require('dialog'),
    ipc = require('electron').ipcMain,
    electronProxy = require('./background-modules/electronProxy').electronProxy,
    postmanApi = require('./background-modules/postmanApi').postmanApi,
    interceptorManifest = require('./background-modules/interceptorManifest').interceptorManifest,
    menuManager = require('./background-modules/menuManager').menuManager,
    windowManager = require('./background-modules/windowManager').windowManager;


// Postman's API will run here. will be used by the interceptor for sending captured requests
var API_SERVER_PORT = 8082,
    thisVersion = null,
    thisName = null,
    thisPlatform = "OSX",
    initUrl = null, //URL set when app is opened via a postman:// link
    immediateUpdateFunction = null; //function to call when "restartAndUpdate" is clicked


function attachUpdaterListeners() {
  autoUpdater.on('update-available', function(update) {
    console.log("update-available: " + JSON.stringify(update));
  });

  autoUpdater.on('checking-for-update', function(update) {
    console.log("checking-for-update: " + JSON.stringify(update));
  });

  autoUpdater.on('update-downloaded', function(event, notes, name, date, url, quitAndUpdate) {
    console.log("update-downloaded: " + notes + " " + name + " " + url);
    immediateUpdateFunction = quitAndUpdate;
    windowManager.sendInternalMessage({
      "event": "electronUpdateDownloaded",
      "object": name,
      "object2": notes
    });
  });

  autoUpdater.on('update-not-available', function(a) {
    console.log("Update not available");
    windowManager.sendInternalMessage({
      event: "electronUpdateNotFound"
    });
  });

  autoUpdater.on('error', function(a,b) {
    console.log("autoUpdate error: " + JSON.stringify(a) + " " + JSON.stringify(b));
    windowManager.sendInternalMessage({
      event: "electronUpdateError"
    });
  });
}

function attachIpcListeners() {
  ipc.on('newRunnerWindow', function(event, arg) {
    console.log("new runner window event received")
    windowManager.newRunnerWindow(arg);
  });

  ipc.on('startBrowserLogin', function(event, authUrl) {
    var authWindow = new BrowserWindow({ width: 800, height: 600, show: false, 'node-integration': false, 'title': 'Postman'});
    authWindow.loadUrl(authUrl);
    authWindow.show();
    console.log("Starting Browser login with URL: " + authUrl);
    authWindow.webContents.on('did-get-redirect-request', function(event, oldUrl, newUrl) {
      console.log("Browser redirect to newUrl = " + newUrl);
      var error = /\?error=(.+)$/.exec(newUrl);

      if (error) {
        // Close the browser if code found or error
        console.log("Error: ", error);
        windowManager.sendInternalMessage({event: "browserLoginError"});
        authWindow.close();
      }

      if(newUrl.indexOf("https://erisedstraehruoytubecafruoytonwohsi.chromiumapp.org") == 0) {
        //send back to renderer
        console.log("Send success back to renderer: ", newUrl);
        windowManager.sendInternalMessage({event: "browserLoginCallback", object: newUrl});
        authWindow.close();
      }
    });

    authWindow.on('close', function() {
      authWindow = null;
    }, false);
  });

  ipc.on("messageToElectron", function(event, arg) {
    if(arg.event === "startProxy") {
      var port = 8080;
      if(arg.data && arg.data.port) {
        port = arg.data.port;
      }
      if(typeof port === "string") {
        port = parseInt(port);
      }
      console.log("Starting proxy on port: " + port);
      try {
        var ret = electronProxy.startProxy(
            port,
            function () {
              sendInternalMessage({event: "proxyClosed", object: {}})
            },
            sendCapturedProxyRequest
        );
        event.sender.send("proxyStarted", ret);
        windowManager.sendInternalMessage({event: "proxyNotif", "object": "start", "object2": "success"});
      }
      catch(e) {
        //error while starting proxy
        console.log("Error while starting proxy: " , e);
        windowManager.sendInternalMessage({event: "proxyNotif", "object": "start", "object2": "failure"});
      }
    }
    else if(arg.event === "stopProxy") {
      try {
        electronProxy.stopProxy();
        windowManager.sendInternalMessage({event: "proxyNotif", "object": "stop", "object2": "success"});
      }
      catch(e) {
        windowManager.sendInternalMessage({event: "proxyNotif", "object": "stop", "object2": "failure"});
      }
    }
    else if(arg.event === "installInterceptorManifest") {
      installInterceptorManifest();
    }
    else if(arg.event==="updateElectronVersion") {
      updateVersion(arg);
    }
    else if(arg.event==="restartAndUpdate") {
      restartAndUpdate();
    }
  });

  ipc.on('getSaveTarget', function(event, arg) {
    var retPath = showSaveDialog(event.sender, arg);
    if(!retPath) {
      event.returnValue = null;
    }
    else {
      event.returnValue = retPath;
    }
  });

  ipc.on("sendToAllWindows", function(event, arg) {
    arg = JSON.parse(arg);
    windowManager.sendInternalMessage(arg);

    if(arg.event==="pmWindowPrimaryChanged") {
      windowManager.primaryId = arg.object;
      console.log("Setting primary to: " + windowManager.primaryId);
    }
  });

  ipc.on("newRequesterWindow", function(event, arg) {
    console.log("new requester window event received")
    windowManager.newRequesterWindow()
  });
}

process.on('uncaughtException',function(e) {
  handleUncaughtError(e)
});

function handleUncaughtError() {
  //Can happen for proxy error
  //explore other possibilities
  //TODO: Kane
}

function openCustomURL(url) {
  shell.openExternal(url);
}

function runPostmanShortcut(action, url) {
  if(action == "appQuit") {
    app.quit();
  }
  else if(action == "reloadWindow") {
    var win = BrowserWindow.getFocusedWindow();
    if(win) {
      win.reloadIgnoringCache();
    }
  }
  else if(action == "newWindow") {
    windowManager.newRequesterWindow();
  }
  else if(action == "toggleDevTools") {
    var win = BrowserWindow.getFocusedWindow();
    if(win) {
      win.toggleDevTools();
    }
  }
  else if(action == "fullScreen") {
    var win = BrowserWindow.getFocusedWindow();
    if(win) {
      win.setFullScreen(true);
    }
    else {
      windowManager.newRequesterWindow();
    }
  }
  else if(action == "openCustomUrl") {
    openCustomURL(url);
  }
  else {
    windowManager.sendToFirstWindow({
      name: "internalEvent",
      data: {
        event: action
      }
    });
  }
}

function restartAndUpdate() {
  if(typeof immediateUpdateFunction === "function") {
    immediateUpdateFunction();
  }
}

function updateVersion(arg) {
    autoUpdater.setFeedUrl(getFeedUrl(arg));
    autoUpdater.checkForUpdates();
}

function getFeedUrl(arg) {
    return "https://app.getpostman.com/api/electron_updates_auto?" +
        "channel=" + arg.data.channel +
        "&current_version=" + arg.data.version +
        "&user_id=" + arg.data.userId +
        "&app_id=" + arg.data.appId +
        "&user_agent=" + encodeURIComponent(arg.data.userAgent) +
        "&platform=" + encodeURIComponent(arg.data.platform);
}

function sendCapturedProxyRequest(url, method, headers, data) {
	if(!data) {
		data = "";
	}
	windowManager.sendInternalMessage({
      event: "proxyRequestCaptured",
      object: {
      	url: url,
      	method: method,
      	headers: headers,
      	data: data
      }
    });
}

function installInterceptorManifest() {
  var manifest = interceptorManifest.getManifest("osx");
  interceptorManifest.saveFile("osx", manifest);
}

// Quit when all windows are closed.
app.on('window-all-closed', function() {
    if (process.platform != 'darwin')
        app.quit();
});

function sendToAllWindows(message) {
  //send event to all other windows
  var numWindowsLeft = 0;
  if(openWindowIds && openWindowIds.length) {
    numWindowsLeft = openWindowIds.length;
  }

  for(var i=0;i<numWindowsLeft;i++) {
    var bWindow = BrowserWindow.fromId(parseInt(openWindowIds[i]));
    if(!bWindow) {
      continue;
    }
    bWindow.webContents.send('electronWindowMessage', message);
  }
}


function sendToFirstWindow(message) {
  var numWindowsLeft = openWindowIds.length;
  for(var i=0;i<numWindowsLeft;i++) {
    var bWindow = BrowserWindow.fromId(parseInt(openWindowIds[i]));
    if(!bWindow) {
      continue;
    }
    console.log("Sending electronWindowMessage");
    bWindow.webContents.send('electronWindowMessage', message);
    return;
  }
}

function focusFirstWindow() {
  var numWindowsLeft = openWindowIds.length;
  for(var i=0;i<numWindowsLeft;i++) {
    var bWindow = BrowserWindow.fromId(parseInt(openWindowIds[i]));
    if(!bWindow) {
      continue;
    }
    bWindow.show();
    bWindow.restore();
    return;
  }
}

//when a window closes
function windowClosed(windowId) {
  //remove windowId from openWindowIds
  var index = openWindowIds.indexOf(windowId);
  if(index!==-1) {
    openWindowIds.splice(index, 1);
  }

  //send event to all other windows
  sendToAllWindows({
    name: "otherWindowClosed",
    data: {
      "id": windowId
    }
  });
}

function showSaveDialog(window, fileName) {
  var savePath = dialog.showSaveDialog({
    title: "Select path to save file",
    defaultPath: fileName
  });
  return savePath;
}

attachIpcListeners();
attachUpdaterListeners();

thisVersion = app.getVersion();
thisName = app.getName();
windowManager.initialize(thisVersion);


windowManager.setShortcutFunction(runPostmanShortcut);
var dockMenu = Menu.buildFromTemplate([
  { label: 'New Collection', click: function() {runPostmanShortcut('newCollection');} },
  { label: 'New Window ', click: function() {runPostmanShortcut('newWindow');}}
]);
// This method will be called when Electron has done everything
// initialization and ready for creating browser windows.
app.on('ready', function() {
  windowManager.newRequesterWindow(1);
  if (app.dock) { // app.dock is only available on OSX
    app.dock.setMenu(dockMenu);
  }
});

app.on('open-url', function(x, url) {
  windowManager.initUrl = url;
  windowManager.openUrl(url);
});

// Quit when all windows are closed.
app.on('window-all-closed', function() {
  if (process.platform != 'darwin')
    app.quit();
});

app.on('activate', function(e, hasWindows) {
  if(!hasWindows) {
    windowManager.newRequesterWindow(1);
  }
});
