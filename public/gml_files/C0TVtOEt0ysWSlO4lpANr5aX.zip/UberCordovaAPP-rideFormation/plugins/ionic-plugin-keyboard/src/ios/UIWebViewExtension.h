@interface UIWebView (HackishAccessoryHiding)
@property (nonatomic, assign) BOOL hackishlyHidesInputAccessoryView;
//@property (nonatomic, assign) BOOL styleDark;
@end
