/**
 *
 * Created by Matthias on 12/4/15.
 */

'use strict';

ApplicationConfiguration.registerModule('users',[
    'ionic'
]);
