/**
 *
 * Created by Matthias on 2/17/16.
 */

angular.module('uber_core').service('RideFormation',[function(){

}]);
