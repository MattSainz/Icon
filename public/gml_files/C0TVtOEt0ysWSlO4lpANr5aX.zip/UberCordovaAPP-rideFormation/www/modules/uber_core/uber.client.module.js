/**
 *
 *
 * Created by Matthias on 12/4/15.
 */

ApplicationConfiguration.registerModule('uber_core',[
  'ionic',
  'ngResource'
]);
