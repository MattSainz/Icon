/**
 *
 * Created by Matthias on 12/4/15.
 */

angular.module('uber_core').controller('CompletedRideController', [
  '$scope',
  'Authentication',
  function($scope, Authentication){

  }
]);
