/**
 *
 * Created by Matthias on 12/4/15.
 */

angular.module('uber_core').controller('SavedRideController', [
  '$scope',
  'Authentication',
  function($scope, Authentication){

  }
]);
