/**
 *
 * Created by Matthias on 12/4/15.
 */

angular.module('uber_core').controller('PendingRideController', [
    '$scope',
    '$cordovaGeolocation',
    function ($scope, $cordovaGeolocation) {

    }
]);
